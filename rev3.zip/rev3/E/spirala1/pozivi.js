var istina;
var dinci=false;
var dosadasnjeslike=[];
let Pozivi=(function(){
    var poceci2=[1,4,4,0,2,5,0,3,6,1,4,6];
    var ajax=new XMLHttpRequest();
function ucitavanje(){
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            let re= JSON.parse(ajax.responseText);
            vandredna=re.vandredna;
            periodicna=re.periodicna;
            Kalendar.ucitajPodatke(periodicna,vandredna);
    }
}
ajax.open("GET","./zauzeca.json");
        ajax.send();}
function klikdatumaImp1(i){
    var dan=Number(i.children[0].children[0].children[0].innerText);
    var klasa=i.children[0].children[1].children[0].className;
    var mjesec=t;
    var pocetak=document.getElementById('poc').value;
    var kraj=document.getElementById('kr').value;
    var cekirano=document.getElementById('cek').checked;
    var kojijedan=(dan+poceci2[t]-1)%7;
    var sala2=document.getElementById('izbor').value;
    var semestar="";
    var datum="";
    var objekat;
    if(dan<10)
    datum=datum+"0"+String(dan)+".";
    else
    datum=datum+String(dan)+".";
    if(mjesec<9)
    datum=datum+"0"+String(mjesec+1)+".2019";
    else
    datum=datum+String(mjesec+1)+".2019";
    if(mjesec>=1 || mjesec<=5)
        semestar="ljetni";
    if(((mjesec>=9 && mjesec<=11)|| mjesec==0))
        semestar="zimski";
    if(cekirano){
         objekat={
            dan:kojijedan,
            semestar:semestar,
            pocetak:pocetak,
            kraj:kraj,
            naziv:sala2,
            predavac:"blabla"
        };
    }
    else{
        objekat={
            datum:datum,
            pocetak:pocetak,
            kraj:kraj,
            naziv:sala2,
            predavac:"blabla"
        };
    }
    if(klasa=="zauzeta"){
        var string="Nije moguće rezervisati salu "+sala2+" za navedeni datum "+datum.substr(0,2)+"/"+datum.substr(3,2)+"/"+datum.substr(6,4)+" i termin od "+pocetak+" do "+kraj+"!";
        window.alert(string);
    }
    else if(pocetak=="" || kraj==""){
        window.alert("Molimo unesite sve potrebne podatke za rezervaciju!");
    }
    else if(mjesec>5 && mjesec<9){
        window.alert("Nije moguće rezervisati salu tokom ljetnog raspusta!");
    }
    else if((Number(pocetak.substring(0,2) ) )*60+(Number(pocetak.substring(3,5) ) )>=(Number(kraj.substring(0,2) ) )*60+(Number(kraj.substring(3,5)))){
        window.alert("Vrijeme kraja rezervacije mora biti poslije vremena pocetka rezervacije!");
    }
    else{
        let proba=confirm("Da li ste sigurni da želite rezervisati ovaj termin?");
        if(proba){
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    if(ajax.responseText.substring(0,1)=="{"){
                    let re= JSON.parse(ajax.responseText);
                    vandredna=re.vandredna;
                    periodicna=re.periodicna;
                    Kalendar.ucitajPodatke(periodicna,vandredna);
                    Kalendar.obojiZauzeca(0,t,sala2,pocetak,kraj);}
                    else{
                        window.alert(ajax.responseText);
                    }
                }
            }
            ajax.open("POST","http://localhost:8080/kalendar",true);
            ajax.setRequestHeader("Content-Type","application/json");
            ajax.send(JSON.stringify(objekat));
        }
    }
}
function prvoucitavanjepocetnetestimp1(){
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
          var niz=JSON.parse(ajax.responseText);
            document.getElementsByClassName('slajba')[0].src=niz[0];
            dosadasnjeslike.push(niz[0]);
            document.getElementsByClassName('slajba')[1].src=niz[1];
            dosadasnjeslike.push(niz[1]);
            document.getElementsByClassName('slajba')[2].src=niz[2];
            dosadasnjeslike.push(niz[2]);
    }
}
    ajax.open("GET","http://localhost:8080/slajbe");
    ajax.send();
}
function sljedecitestImp1(){
    document.getElementById('pret').disabled=false;
    let dokle=0;
    for(let i=0;i<dosadasnjeslike.length;i++){
        if(document.getElementsByClassName('slajba')[0].src==dosadasnjeslike[i]){
            dokle=i;
        }
    }
    dokle+=3;
    if(dokle==dosadasnjeslike.length){
        ajax.onreadystatechange = function() {// Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200){
              var niz=JSON.parse(ajax.responseText);
                if(niz.sljedecetri.length==1){
                    document.getElementsByClassName('slajba')[0].src=niz.sljedecetri[0];
                dosadasnjeslike.push(niz.sljedecetri[0]);
                document.getElementsByClassName('slajba')[1].src="https://dummyimage.com/400x300/fff/fff.png";
                document.getElementsByClassName('slajba')[2].src="https://dummyimage.com/400x300/fff/fff.png";
                }
                else if(niz.sljedecetri.length==2){
                    document.getElementsByClassName('slajba')[0].src=niz.sljedecetri[0];
                    dosadasnjeslike.push(niz.sljedecetri[0]);
                    document.getElementsByClassName('slajba')[1].src=niz.sljedecetri[1];
                    dosadasnjeslike.push(niz.sljedecetri[1]); 
                    document.getElementsByClassName('slajba')[2].src="https://dummyimage.com/400x300/fff/fff.png";
                }
                else{
                document.getElementsByClassName('slajba')[0].src=niz.sljedecetri[0];
                dosadasnjeslike.push(niz.sljedecetri[0]);
                document.getElementsByClassName('slajba')[1].src=niz.sljedecetri[1];
                dosadasnjeslike.push(niz.sljedecetri[1]);
                document.getElementsByClassName('slajba')[2].src=niz.sljedecetri[2];
                dosadasnjeslike.push(niz.sljedecetri[2]);}
                if(niz.kraj){
                document.getElementById('sljed').disabled=true;
                istina=0;
                dinci=true;
                }
        }
    }
    ajax.open("GET","http://localhost:8080/slajbe2");
        ajax.send();
    }
    else{
        if(dinci)
        istina++;
        if(istina==0)
        document.getElementById('sljed').disabled=true;
        if(dokle+1==dosadasnjeslike.length){
            document.getElementsByClassName('slajba')[0].src=dosadasnjeslike[dokle];
            document.getElementsByClassName('slajba')[1].src="https://dummyimage.com/400x300/fff/fff.png";
                document.getElementsByClassName('slajba')[2].src="https://dummyimage.com/400x300/fff/fff.png";
        }
        else if(dokle+2==dosadasnjeslike.length){
            document.getElementsByClassName('slajba')[0].src=dosadasnjeslike[dokle];
            document.getElementsByClassName('slajba')[1].src=dosadasnjeslike[dokle+1];
            document.getElementsByClassName('slajba')[2].src="https://dummyimage.com/400x300/fff/fff.png";
        }
        else{
        document.getElementsByClassName('slajba')[0].src=dosadasnjeslike[dokle];
        document.getElementsByClassName('slajba')[1].src=dosadasnjeslike[dokle+1];
        document.getElementsByClassName('slajba')[2].src=dosadasnjeslike[dokle+2];}
    }
}
function prethodnitestImp1(){
    if(dinci)
    istina--;
    document.getElementById('sljed').disabled=false;
    let dokle=0;
    for(let i=0;i<dosadasnjeslike.length;i++){
        if(document.getElementsByClassName('slajba')[0].src==dosadasnjeslike[i]){
            dokle=i;
        }
    }
    if(dokle==3)
    document.getElementById('pret').disabled=true;
    dokle-=3;
    document.getElementsByClassName('slajba')[0].src=dosadasnjeslike[dokle];
    document.getElementsByClassName('slajba')[1].src=dosadasnjeslike[dokle+1];
    document.getElementsByClassName('slajba')[2].src=dosadasnjeslike[dokle+2];
}
return {
ucitavanje:ucitavanje,
klikdatuma:klikdatumaImp1,
prvoucitavanjepocetnetest:prvoucitavanjepocetnetestimp1,
sljedecitest:sljedecitestImp1,
prethodnitest:prethodnitestImp1
}
}());