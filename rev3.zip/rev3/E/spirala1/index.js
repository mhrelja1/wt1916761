var doklesam=0;
var content;
var poceci3=[1,4,4,0,2,5,0,3,6,1,4,6];
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.get("/",function(req,res){
    res.sendFile(__dirname+"/pocetna.html");
});
app.get("/zauzeca.json",function(req,res){
    res.sendFile(__dirname+"/zauzeca.json");
});
app.get("/slajbe",function(req,res){
    var prvetri=[];
    doklesam=0;
    fs.readdir('./images',function(err,slikice){
        for(let i=0;i<3;i++){
            prvetri.push('http://localhost:8080/images/'+slikice[i]);
        }
        res.json(prvetri);
        doklesam+=3;
    });
});
app.get("/slajbe2",function(req,res){
    var sljedecetri=[];
    var kraj=false;
    var velicina=doklesam+3;
    fs.readdir('./images',function(err,slikice){
        if(doklesam+3>=slikice.length){
        kraj=true;
        velicina=slikice.length;}
        
        for(let i=doklesam;i<velicina;i++){
            sljedecetri.push('http://localhost:8080/images/'+slikice[i]);
        }
        let din={sljedecetri,kraj};
        res.json(din);
        doklesam+=3;
    });
});
app.post("/kalendar",function(req,res){
    var tijelo=req.body;
    fs.readFile('./zauzeca.json',function(err,data){
        content=JSON.parse(data);
        if(Object.keys(tijelo).length==5){
            var prolazi=true;
            for(var l=0;l<content.vandredna.length;l++){
                if(tijelo.datum==content.vandredna[l].datum && tijelo.naziv==content.vandredna[l].naziv && (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )>=( ( Number( content.vandredna[l].pocetak.substring(0,2) ) )*60+Number(content.vandredna[l].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.vandredna[l].kraj.substring(0,2) ) )*60+Number(content.vandredna[l].kraj.substring(3,5))))
                || (( ( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number( content.vandredna[l].pocetak.substring(0,2) ) )*60+Number(content.vandredna[l].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )<=( ( Number( content.vandredna[l].kraj.substring(0,2) ) )*60+Number(content.vandredna[l].kraj.substring(3,5)))))
                || (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.vandredna[l].pocetak.substring(0,2) ) )*60+Number(content.vandredna[l].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number(content.vandredna[l].kraj.substring(0,2) ) )*60+Number(content.vandredna[l].kraj.substring(3,5))))))){
                    prolazi=false;
                }
            }
            for(var o=0;o<content.periodicna.length;o++){
                if(tijelo.naziv==content.periodicna[o].naziv && ((content.periodicna[o].semestar=='ljetni' && (Number(tijelo.datum.substring(3,5))-1)>=1 && (Number(tijelo.datum.substring(3,5))-1)<=5) || (content.periodicna[o].semestar=='zimski' && 
                (((Number(tijelo.datum.substring(3,5))-1)>=9 && (Number(tijelo.datum.substring(3,5))-1)<=11)|| (Number(tijelo.datum.substring(3,5))-1)==0))) && (Number(tijelo.datum.substring(0,2))+poceci3[Number(tijelo.datum.substring(3,5))-1]-1)%7==content.periodicna[o].dan && (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )>=( ( Number( content.periodicna[o].pocetak.substring(0,2) ) )*60+Number(content.periodicna[o].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.periodicna[o].kraj.substring(0,2) ) )*60+Number(content.periodicna[o].kraj.substring(3,5))))
                || (( ( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number( content.periodicna[o].pocetak.substring(0,2) ) )*60+Number(content.periodicna[o].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )<=( ( Number( content.periodicna[o].kraj.substring(0,2) ) )*60+Number(content.periodicna[o].kraj.substring(3,5)))))
                || (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.periodicna[o].pocetak.substring(0,2) ) )*60+Number(content.periodicna[o].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number(content.periodicna[o].kraj.substring(0,2) ) )*60+Number(content.periodicna[o].kraj.substring(3,5))))))){
                    prolazi=false;
                }
            }
            if(prolazi){
                var response="";
                content.vandredna.push(tijelo);
                var response1=response+"{"+"\n"+"\"periodicna\":["+"\n";
                for(var t=0;t<content.periodicna.length-1;t++){
                    response1=response1+JSON.stringify(content.periodicna[t])+","+"\n";
                }
                response1=response1+JSON.stringify(content.periodicna[content.periodicna.length-1])+"\n"+"        ],\n\"vandredna\":[\n";
                for(var t=0;t<content.vandredna.length-1;t++){
                    response1=response1+JSON.stringify(content.vandredna[t])+","+"\n";
                }
                response1=response1+JSON.stringify(content.vandredna[content.vandredna.length-1])+"\n        ]\n}";
                fs.writeFile('./zauzeca.json',response1,function(err){
                res.json(content);
                });
            }
            else{
                response="Nije moguće rezervisati salu "+tijelo.naziv+" za navedeni datum "+tijelo.datum.substr(0,2)+"/"+tijelo.datum.substr(3,2)+"/"+tijelo.datum.substr(6,4)+" i termin od "+tijelo.pocetak+" do "+tijelo.kraj+"!";
                res.json(response);
            }
        }
        else{
            var prolazi2=true;
            for(var q=0;q<content.vandredna.length;q++){
                if((Number(content.vandredna[q].datum.substring(0,2))+poceci3[Number(content.vandredna[q].datum.substring(3,5))-1]-1)%7==tijelo.dan && tijelo.naziv==content.vandredna[q].naziv && ((tijelo.semestar=='ljetni' && (Number(content.vandredna[q].datum.substring(3,5))-1)>=1 && (Number(content.vandredna[q].datum.substring(3,5))-1)<=5) || (tijelo.semestar=='zimski' && 
                (((Number(content.vandredna[q].datum.substring(3,5))-1)>=9 && (Number(content.vandredna[q].datum.substring(3,5))-1)<=11)|| (Number(content.vandredna[q].datum.substring(3,5))-1)==0))) && (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )>=( ( Number( content.vandredna[q].pocetak.substring(0,2) ) )*60+Number(content.vandredna[q].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.vandredna[q].kraj.substring(0,2) ) )*60+Number(content.vandredna[q].kraj.substring(3,5))))
                || (( ( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number( content.vandredna[q].pocetak.substring(0,2) ) )*60+Number(content.vandredna[q].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )<=( ( Number( content.vandredna[q].kraj.substring(0,2) ) )*60+Number(content.vandredna[q].kraj.substring(3,5)))))
                || (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.vandredna[q].pocetak.substring(0,2) ) )*60+Number(content.vandredna[q].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number(content.vandredna[q].kraj.substring(0,2) ) )*60+Number(content.vandredna[q].kraj.substring(3,5))))))){
                    prolazi2=false;
                }
            }
            for(var f=0;f<content.periodicna.length;f++){
                if(tijelo.naziv==content.periodicna[f].naziv && tijelo.semestar==content.periodicna[f].semestar && tijelo.dan==content.periodicna[f].dan &&
                    (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )>=( ( Number( content.periodicna[f].pocetak.substring(0,2) ) )*60+Number(content.periodicna[f].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.periodicna[f].kraj.substring(0,2) ) )*60+Number(content.periodicna[f].kraj.substring(3,5))))
                || (( ( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number( content.periodicna[f].pocetak.substring(0,2) ) )*60+Number(content.periodicna[f].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )<=( ( Number( content.periodicna[f].kraj.substring(0,2) ) )*60+Number(content.periodicna[f].kraj.substring(3,5)))))
                || (( ( (Number ( tijelo.pocetak.substring(0,2) ) )*60+(Number(tijelo.pocetak.substring(3,5) ) ) )<=( ( Number( content.periodicna[f].pocetak.substring(0,2) ) )*60+Number(content.periodicna[f].pocetak.substring(3,5)))) && 
                (( (Number ( tijelo.kraj.substring(0,2) ) )*60+(Number(tijelo.kraj.substring(3,5) ) ) )>=( ( Number(content.periodicna[f].kraj.substring(0,2) ) )*60+Number(content.periodicna[f].kraj.substring(3,5))))))){
                    prolazi2=false;
                }
            }
            if(prolazi2){
                var odgovor=""
                content.periodicna.push(tijelo);
                var response2=odgovor+"{"+"\n"+"\"periodicna\":["+"\n";
                for(var t=0;t<content.periodicna.length-1;t++){
                    response2=response2+JSON.stringify(content.periodicna[t])+","+"\n";
                }
                response2=response2+JSON.stringify(content.periodicna[content.periodicna.length-1])+"\n"+"        ],\n\"vandredna\":[\n";
                for(var t=0;t<content.vandredna.length-1;t++){
                    response2=response2+JSON.stringify(content.vandredna[t])+","+"\n";
                }
                response2=response2+JSON.stringify(content.vandredna[content.vandredna.length-1])+"\n        ]\n}";
                fs.writeFile('./zauzeca.json',response2,function(err){
                    res.json(content);
                });
            }
            else{
                response="Nije moguće periodično zauzeti ovu salu u traženom terminu!";
                res.json(response);
            }
        }
    });
});
app.listen(8080);