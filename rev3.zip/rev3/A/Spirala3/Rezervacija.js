let months = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
let mjeseci = document.getElementById("mjesec");
var tmjesec;
let sedmica = ["nedeljom","ponedeljkom","utorkom","srijedom","četvrtkom","petkom","subotom"];

window.onload=function(){
  Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
  ucitajAjax(Kalendar.ucitajPodatke);
  draw();
}


let Kalendar = (function(){    
      var periodicni=[];
      var vandredni=[];
      function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj)
      {
        var aid1=[];
        var aid2=[];
        var a = parseInt(kraj.substr(0,2)) - parseInt(pocetak.substr(0,2))
        var npocetak = pocetak;
        var npocetak1 = pocetak;
        var npocetak2 = pocetak;
        var nkraj = kraj;
        var nkraj1 = kraj;
        var nkraj2 = kraj;
        for(var g= 0;g<periodicni.length ; g++)
        {
          if( ( pocetak == periodicni[g].pocetak || kraj == periodicni[g].kraj || (pocetak >= periodicni[g].pocetak && pocetak <= periodicni[g].kraj) || (pocetak <= periodicni[g].pocetak && kraj >= periodicni[g].kraj) )  && sala == periodicni[g].sala)
          {
            if( (mjesec >=9 && mjesec <12) || (mjesec>=0 && mjesec<1) )
            {
              if(periodicni[g].semestar == "zimski")
              {
                aid1.push(periodicni[g]);
                if(a>0)
                {
                  for(var l =0;l<=a;l++)
                  {
                    var hel = parseInt(npocetak.substr(0,2)) + l;
                    if(hel < 0)
                    {
                      hel = (-1) * hel;
                    }
                    if(hel >= 10)
                    {
                      hel = hel - 10;
                    }
                    npocetak = npocetak.substr(0,1) + hel + npocetak.substr(2,4);
                    var lt = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: npocetak,kraj: kraj,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    aid1.push(lt);
                    var hel7 = parseInt(nkraj[1]) - l;
                    if(hel7 < 0)
                    {
                      hel7 = (-1) * hel7;
                    }
                    if(hel7 >= 10)
                    {
                      hel7 = hel7 - 10;
                    }
                    nkraj = nkraj.substr(0,1) + hel7 + nkraj.substr(2,4);
                    var lt1 = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: pocetak,kraj: nkraj,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    var lt2 = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: npocetak,kraj: nkraj,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    aid1.push(lt1);
                    aid1.push(lt2);
                    npocetak = pocetak;
                    nkraj = kraj;
                  }
                }
              }
            }
            else if (mjesec <7)
            {
              if(periodicni[g].semestar == "ljetni")
              {
                aid1.push(periodicni[g]);
                if(a>0)
                {
                  for(var li =0;li<a;li++)
                  {
                    var hel2 = parseInt(npocetak1.substr(0,2)) + li;
                    if(hel2 < 0)
                    {
                      hel2 = (-1) * hel2;
                    }
                    if(hel2 >= 10)
                    {
                      hel2 = hel2 - 10;
                    }
                    npocetak1 = npocetak1.substr(0,1) + hel2 + npocetak1.substr(2,4);
                    var lt3 = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: npocetak1,kraj: kraj,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    aid1.push(lt3);
                    var hel3 = parseInt(nkraj1[1]) - li;
                    if(hel3 < 0)
                    {
                      hel3 = (-1) * hel3;
                    }
                    if(hel3 >= 10)
                    {
                      hel3 = hel3 - 10;
                    }
                    nkraj1 = nkraj1.substr(0,1) + hel3 + nkraj1.substr(2,4);
                    var lt4 = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: pocetak,kraj: nkraj1,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    var lt5 = {dan : periodicni[g].dan,semestar: periodicni[g].semestar,sala:periodicni[g].sala,pocetak: npocetak1,kraj: nkraj1,naziv:periodicni[g].naziv, predavac: periodicni[g].predavac};
                    aid1.push(lt4);
                    aid1.push(lt5);
                    npocetak1 = pocetak;
                    nkraj1 = kraj;
                  }
                }
              }
            }
          }
        }
        for(var m= 0;m<vandredni.length ; m++)
        {
          if( (pocetak == vandredni[m].pocetak || kraj == vandredni[m].kraj || (pocetak >= vandredni[m].pocetak && pocetak <= vandredni[m].kraj) || (pocetak <= vandredni[m].pocetak && kraj >= vandredni[m].kraj) ) && sala == vandredni[m].sala)
          {
            aid2.push(vandredni[m]);
            if(a>0)
            {
              for(var lit =0;lit<a;lit++)
              {
                var hel4 = parseInt(npocetak2.substr(0,2)) + lit;
                if(hel4 < 0)
                {
                  hel4 = (-1) * hel4;
                }
                if(hel4 >= 10)
                {
                  hel4 = hel4 - 10;
                }
                npocetak2 = npocetak2.substr(0,1) + hel4 + npocetak2.substr(2,4);
                var lt6 = {datum : vandredni[m].datum,sala: vandredni[m].sala,pocetak: npocetak2,kraj: kraj,naziv:vandredni[m].naziv,predavac: vandredni[m].predavac};
                aid2.push(lt6);
                var hel5 = parseInt(nkraj2[1]) - lit;
                if(hel5 < 0)
                {
                  hel5 = (-1) * hel5;
                }
                if(hel5 >= 10)
                {
                  hel5 = hel5 - 10;
                }
                nkraj2 = nkraj1.substr(0,1) + hel5 + nkraj2.substr(2,4);
                var lt7 = {datum : vandredni[m].datum,sala: vandredni[m].sala,pocetak: pocetak,kraj: nkraj2,naziv:vandredni[m].naziv,predavac: vandredni[m].predavac};
                var lt8 = {datum : vandredni[m].datum,sala: vandredni[m].sala,pocetak: npocetak2,kraj: nkraj2,naziv:vandredni[m].naziv,predavac: vandredni[m].predavac};
                aid2.push(lt7);
                aid2.push(lt8);
                npocetak2 = pocetak;
                nkraj2 = kraj;
              }
            }
          }
        }
        let firstDay = (new Date(2019, mjesec)).getDay();
        let daysInMonth = 32 - new Date(2019, mjesec, 32).getDate();

        let tbl = kalendarRef.getElementsByTagName("tbody")[0];

        tbl.innerHTML = "";
        mjeseci.innerHTML = months[mjesec];
        tmjesec = mjesec;

        let date = 1;
        for (let i = 0; i < 6; i++) {
            let row = document.createElement("tr");
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < firstDay) {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode("");
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                }
                else if (date > daysInMonth) {
                    break;
                }
                else {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode(date);
                    var cellStil = document.createAttribute("class");
                    cellStil.value = "slobodna";
                    var cellID = document.createAttribute("id");
                    cellID.value = new Date(2019,mjesec,date);
                    cell.setAttributeNode(cellID);
                    for(var k = 0; k < aid1.length;k++)
                    {
                      if(aid1[k].dan === new Date(2019,mjesec,date).getDay())
                      {
                        
                        cellStil.value = "demo zauzeta";
                      }
                    }
                    for(var h=0;h<aid2.length;h++)
                    {
                      if(new Date(aid2[h].datum).getDate() == new Date(2019,mjesec,date).getDate() && new Date(aid2[h].datum).getMonth() == new Date(2019,mjesec,date).getMonth()  && new Date(aid2[h].datum).getFullYear() == new Date(2019,mjesec,date).getFullYear())
                      {
                      cellStil.value = "demo2 zauzeta";
                      }
                    }
                    if(cellStil.value == "slobodna")
                    {
                      cell.addEventListener("click",function(){cellKlik(this.id)});
                    }
                    cell.setAttributeNode(cellStil);
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                    date++;
                }
            }
            tbl.appendChild(row); 
        }
      }     
      function ucitajPodatkeImpl(periodicna, vandredna)
      { 
        periodicni=periodicna;
        vandredni=vandredna;     
      }    
      function iscrtajKalendarImpl(kalendarRef,mjesec)
      {
        let firstDay = (new Date(2019, mjesec)).getDay();
        let daysInMonth = 32 - new Date(2019, mjesec, 32).getDate();

        let tbl = kalendarRef.getElementsByTagName("tbody")[0];

        tbl.innerHTML = "";
        mjeseci.innerHTML = months[mjesec];
        tmjesec = mjesec;

        let date = 1;
        for (let i = 0; i < 6; i++) {
            let row = document.createElement("tr");
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < firstDay) {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode("");
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                }
                else if (date > daysInMonth) {
                    break;
                }
                else {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode(date);
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                    date++;
                }
            }
            tbl.appendChild(row); 
        }
      }
       
       return {
        obojiZauzeca: obojiZauzecaImpl,         
        ucitajPodatke: ucitajPodatkeImpl,         
        iscrtajKalendar: iscrtajKalendarImpl  
         }     
        }() );

function naredni() {
          if(tmjesec >=0 && tmjesec <11)
          {
          tmjesec = tmjesec + 1;
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
          }
      }
      
function prethodni() {
        if(tmjesec >0 && tmjesec <12)
        {
        tmjesec = tmjesec - 1;
        Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
        }
      }
function draw()
{ 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
}

function ucitajAjax(fnCall)
{
  var pr = [];
  var vr= [];
  var ajax = new XMLHttpRequest();
    ajax.open("POST","http://localhost:8080",true);
    ajax.send();
    ajax.onload = function()
    {
      var jsonRez = JSON.parse(ajax.responseText);
      pr=jsonRez.periodicna;
      vr=jsonRez.vandredna;
      //console.log(pr,vr);
      fnCall(pr,vr);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
    }
 }

function cellKlik(datum)
{
  datum = new Date(datum);
  var typ;
  var sem;
  var str = "Izabrali ste: "
  if(document.getElementById("checkrez").checked )
  {
    typ = "periodicno";
  }
  else 
  {
    typ = "vandredno";
  }
  if((datum.getMonth() >9 && datum.getMonth() <12) || datum.getMonth() == 0 ) 
  {
    sem = "zimski";
    str = str + sem + " semestar ";
  }
  if(datum.getMonth() >= 1 && datum.getMonth() <8)
  {
    sem = "ljetni";
    str = str + sem + " semestar ";
  }
  var zahtjev;
  if(typ == "periodicno")
  {
    zahtjev = {tip:typ,dan:datum.getDay(),semestar:sem,sala:document.getElementById("sale").value,pocetak:document.getElementById("pocetak").value.toString(),kraj:document.getElementById("kraj").value.toString(),naziv:"IM",predavac:"H.Fatkic"};
    str = str + " sala: " + document.getElementById("sale").value + " u terminu: " + document.getElementById("pocetak").value.toString() + "-" + document.getElementById("kraj").value.toString() + " svakim/om " + sedmica[datum.getDay()];
  }
  if(typ == "vandredno")
  {
    zahtjev = {tip:typ,datum:datum.getFullYear()+"-"+(datum.getMonth() + 1)+"-"+datum.getDate(),sala:document.getElementById("sale").value,pocetak:document.getElementById("pocetak").value.toString(),kraj:document.getElementById("kraj").value.toString(),naziv:"IM",predavac:"H.Fatkic"};
    var mon = parseInt(datum.getMonth())+1; 
    str = str + " sala: " + document.getElementById("sale").value + " u terminu: " + document.getElementById("pocetak").value.toString() + "-" + document.getElementById("kraj").value.toString()+ " na dan: " +datum.getDate()+"/"+mon+"/"+ datum.getFullYear()
  }
  str = str + ". " + "Kliknite na OK za potvrdu, a Cancel za otkazivanje."
  if (confirm(str)){
    var ajax = new XMLHttpRequest();
    ajax.open("POST","/cell",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(zahtjev));
    ajax.onload = function()
    {
      var jsonRez = JSON.parse(ajax.responseText);
      alert(jsonRez.odgovor);
     ucitajAjax(Kalendar.ucitajPodatke);
    }
  } else {
    alert("Otkazali ste termin!");
  } 
}
/*
ucitajAjax(Kalendar.ucitajPodatke);

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 2);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 3);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 4);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 5);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 6);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 7);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 8);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 9);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 11);
// Testovi za iscrtavanje kalendara sa različitim vrijednostima
var periodicno1 = {dan: 1, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno2 = {dan: 3, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno3 = {dan: 4, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var vandredna1 = {datum: "2019-11-15",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna2 = {datum: "2019-11-21",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var p=[];
var p1=[];
var v1=[];
var v=[];
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa praznim zauzecima
p.push(periodicno1);
p.push(periodicno2);
p.push(periodicno3);
v.push(vandredna1);
v.push(vandredna2);
Kalendar.ucitajPodatke(p,v);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa parcijalno punim zauzecima, i preklapanjem dana
var periodicno4 = {dan: 0, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno5 = {dan: 2, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno6 = {dan: 5, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno7 = {dan: 6, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var vandredna3 = {datum: "2019-11-16",sala:"0-01",pocetak:"14:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna4 = {datum: "2019-11-27",sala:"0-01",pocetak:"13:00", kraj:"16:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna5 = {datum: "2019-12-16",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna6 = {datum: "2019-12-27",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
p.push(periodicno4);
p.push(periodicno5);
p.push(periodicno6);
p.push(periodicno7);
v.push(vandredna3);
v.push(vandredna4);
v.push(vandredna5);
v.push(vandredna6); // Ubacujemo metode koje se ne smiju upisati poput različitog mjeseca ili vremena
Kalendar.ucitajPodatke(p,v); // Overwrite test 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa svim zauzecima
Kalendar.ucitajPodatke(p1,v); // Test sa 1 prazan 1 pun array
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
Kalendar.ucitajPodatke(p,v1); // Test sa 1 prazan 1 pun array
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
var periodicno8 = {dan: 1, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno9 = {dan: 3, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno10 = {dan: 4, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
p.push(periodicno8);
p.push(periodicno9);
p.push(periodicno10);
Kalendar.ucitajPodatke(p,v);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),3,"0-01","13:00","15:00"); // Test ljetnog semestra, samo određeni dani se trebaju obojit
p1.push(periodicno4);
p1.push(periodicno5);
p1.push(periodicno6);
v1.push(vandredna1);
v1.push(vandredna2);
p1.push(periodicno8);
p1.push(periodicno9);
p1.push(periodicno10);
Kalendar.ucitajPodatke(p1,v1);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test zimskog semestra 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  // Test poziva iste metode više puta jedna nakon druge 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-15","13:00","15:00");
*/