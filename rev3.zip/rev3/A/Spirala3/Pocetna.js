let set=0;
let limit=0;
let stariset=[];
let dis =0;
let stop = 0;
let v=0;
let vis=0;

window.onload = function(){
        var str="/row"+1+".png";
        var ajax = new XMLHttpRequest();
        ajax.open("POST","/dobaviSlika",true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send(JSON.stringify({broj:1}));
        ajax.onload = function()
        {
            jsonRez = ajax.responseText;
            stariset.push(jsonRez); 
            limit++;     
        }
    provjeraslika();
    setTimeout(() => {
        naredni();
    }, 500);
}



function provjeraslika()
{
    for(var i=2;i<100;i++)
    {
        (function(i) {
        setTimeout(function() {
        var str="/row"+i+".jpg";
        var ajax = new XMLHttpRequest();
        ajax.open("POST","/setslika",true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send(JSON.stringify({slika:str}));
        ajax.onload = function()
        {
            var jsonRez = ajax.responseText; 
            //console.log(jsonRez);
            if(jsonRez=="ima")
            {
                limit++;
                //console.log(limit);
            }
            if(jsonRez=="nema")
            {
                stop=1;
            }          
        }      
        }, 10);
        })(i);
        if(stop==1)
        {
            break;
        }
    }
}


function naredni()
{
    if(set<=limit && vis==0)
    {
    for(var i = 1;i<4;i++)
    {
        (function(i) {
            setTimeout(function() {
            var s = "sl"+i;
            if(set<limit){
            set++;
            var ajax = new XMLHttpRequest();
            ajax.open("POST","/dobaviSlika",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({broj:set}));
            ajax.onload = function()
            {
            var jsonRez = ajax.responseText;
            stariset.push(jsonRez);
            document.getElementById(s).src=jsonRez;
            dis = 0;}
            if(set==limit)
            {
                var j = (-1) * limit;
                while(j<0)
                {
                    j+=3;
                }
                if(j==2)
                {
                    document.getElementById("sl1").style.visibility = "hidden"; 
                    document.getElementById("sl2").style.visibility = "hidden";
                    v=1;
                }
                if(j==1)
                {
                    document.getElementById("sl1").style.visibility = "hidden";
                    v=2;      
                }
                vis=1;
                dis=0;
                set=set-v;    
            }
            }
            }, 10);
        })(i);
    }
    }
}

function prethodni()
{
    if(set>3 && dis==0)
    {
        if(v>=1)
        {
            stariset.pop(stariset.length);
            stariset.pop(stariset.length);
            stariset.pop(stariset.length);
            console.log(stariset);   
            document.getElementById("sl1").style.visibility = "visible";
            document.getElementById("sl2").style.visibility = "visible";
            document.getElementById("sl3").style.visibility = "visible";
            if(v==2)
            {  
                document.getElementById("sl3").src=stariset[set-1];
                document.getElementById("sl2").src=stariset[set-2];
                document.getElementById("sl1").src=stariset[set-3];    
            }
            else
            {
                document.getElementById("sl3").src=stariset[set];
                document.getElementById("sl2").src=stariset[set-1];
                document.getElementById("sl1").src=stariset[set-2];  
            }
            set= set - 1;
            vis=0;
        }
        if(v==0)
        {
            document.getElementById("sl1").src=stariset[set-5];
            document.getElementById("sl2").src=stariset[set-4];
            document.getElementById("sl3").src=stariset[set-3];
            set=set-3;
            stariset.pop(stariset.length);
            stariset.pop(stariset.length);
            stariset.pop(stariset.length);
            vis=0;
        }
        dis=1;
    }
}