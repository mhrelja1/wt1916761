const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());
app.use(express.static(__dirname));

app.get('/',function(req,res){
    res.sendFile(__dirname+"/Rezervacija.html");
    //console.log(req.header('user-agent'));
    //console.log(req.header('x-forwarded-for') || req.connection.remoteAddress);
    var fs=require('fs');
    fs.readFile(__dirname+"/promet.json", 'utf8',function(err,data)
    {
    var traffic=JSON.parse(data);
    var objekt = {browser:req.header('user-agent'),adresa:req.header('x-forwarded-for') || req.connection.remoteAddress};
    traffic.push(objekt);
    //console.log(traffic);
    var fs = require('fs');
    fs.writeFile(__dirname+"/promet.json", JSON.stringify(traffic),'utf8',function(err)
    {
       if(err) throw err;
    });
    });  
 });

 
app.post('/',function(req,res){
    var fs=require('fs');
    fs.readFile(__dirname+"/zauzeca.json", 'utf8',function(err,data)
    {
    var sale=JSON.parse(data);
    //console.log(sale);
    res.json(sale);
    });  
 });
 let sedmica = ["nedeljom","ponedeljkom","utorkom","srijedom","četvrtkom","petkom","subotom"];
 app.post('/cell',function(req,res){
    //console.log(req.body);
    var fs=require('fs');
    var str = "Termin je uspješno rezervisan";
    var r = 0;
    fs.readFile(__dirname+"/zauzeca.json", 'utf8',function(err,data)
    {
      var sale = JSON.parse(data);
      for(var i = 0;i<sale.length;i++)
      {
         if(req.body.tip == sale[i].tip)
         {
            if(req.body.sala == sale[i].sala)
            {
               if(req.body.pocetak == sale[i].pocetak || req.body.kraj == sale[i].kraj || (req.body.pocetak >= sale[i].pocetak && req.body.pocetak <= sale[i].kraj) || (req.body.pocetak <= sale[i].pocetak && req.body.kraj >= sale[i].kraj))
               {
                  if(req.body.tip == "periodicno")
                  {
                     if(req.body.dan == sale[i].dan)
                     {
                        r = 1;
                        str = "Nije moguće rezervisati salu: " + req.body.sala + " " + sedmica[req.body.dan] + " i u terminu od " + req.body.pocetak + " do " + req.body.kraj + " u semestru: " +req.body.semestar ;
                     }
                  }
                  if(req.body.tip == "vandredno")
                  {
                     if(req.body.datum == sale[i].datum)
                     {
                     r=1;
                     str = "Nije moguće rezervisati salu: " + req.body.sala + " za navedeni datum: " +req.body.datum.substr(8,req.body.datum.length)+"/"+parseInt(req.body.datum.substr(5,7))+"/"+req.body.datum.substr(0,4)+" i termin od " + req.body.pocetak + " do " + req.body.kraj;
                     /*var datum = new Date(parseInt(req.body.datum.substr(0,4)),parseInt(req.body.datum.substr(5,7))-1,parseInt(req.body.datum.substr(8,req.body.datum.length))+1);
                     console.log(datum);*/
                     }
                  }
               }
            }
         }
      }
      if(req.body.tip == "periodicno")
      {
         sale.periodicna.push(req.body);
      }
      if(req.body.tip == "vandredno")
      {
         sale.vandredna.push(req.body);
      }
      //console.log(sale);
      if(r==0)
      {
      var fs = require('fs');
      fs.writeFile(__dirname+"/zauzeca.json", JSON.stringify(sale),'utf8',function(err)
      {
         if(err) throw err;
      });
      }
      res.json({odgovor:str});
    }); 
 });
 app.post('/set0',function(req,res){
    res.send("row1.png");
});
app.post('/set1',function(req,res){
   res.send("row2.jpg");
});
app.post('/set2',function(req,res){
   res.send("row3.jpg");
});
app.post('/set3',function(req,res){
   res.send("row4.jpg");
});

app.post('/setslika',function(req,res){
   var str = "nema";
   const fs = require("fs");
   if (fs.existsSync(__dirname+req.body.slika))
   {
         str="ima";
   }
   //console.log("ima");
   res.send(str);
});
app.post('/dobaviSlika',function(req,res){
   var sk=".png"
   if(req.body.broj > 1)
   {
      sk=".jpg";
   }
   res.send("row"+req.body.broj+sk);
});

 app.listen(8080);
