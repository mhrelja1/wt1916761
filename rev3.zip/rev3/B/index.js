const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get("/index.html", function (req, res) {
	res.sendFile(__dirname + "/index.html");
});

app.get("/", function (req, res) {
	res.sendFile(__dirname + "/pocetna.html");
});

app.get("/pocetna.html", function (req, res) {
	res.sendFile(__dirname + "/pocetna.html");
});

app.get("/slike1", function (req, res) {
	res.write("{\"slika1\" : \"/slikeZaPocetnu/etf1.jpg\", \"slika2\" : \"/slikeZaPocetnu/etf2.png\", \"slika3\" : \"/slikeZaPocetnu/etf3.jpg\"}");
    res.send();
});

app.get("/slike2", function (req, res) {
	res.write("{\"slika4\" : \"/slikeZaPocetnu/etf4.png\", \"slika5\" : \"/slikeZaPocetnu/etf5.jpg\", \"slika6\" : \"/slikeZaPocetnu/etf6.jpeg\"}");
    res.send();
});

app.get("/slike3", function (req, res) {
	res.write("{\"slika7\" : \"/slikeZaPocetnu/etf7.png\", \"slika8\" : \"/slikeZaPocetnu/etf8.jpeg\", \"slika9\" : \"/slikeZaPocetnu/etf9.jpg\"}");
    res.send();
});

app.get("/slike4", function (req, res) {
	res.write("{\"slika10\" : \"/slikeZaPocetnu/etf10.jpg\"}");
    res.send();
});

app.get("/sale.html", function (req, res) {
	res.sendFile(__dirname + "/sale.html");
});

app.get("/rezervacija.html", function (req, res) {
	res.sendFile(__dirname + "/rezervacija.html");
});

app.get("/unos.html", function (req, res) {
	res.sendFile(__dirname + "/unos.html");
});

app.get("/zauzeca.json", function (req, res) {
	res.sendFile(__dirname + "/zauzeca.json");
});

app.post("/zauzeca.json", function (req, res){
	fs.readFile("zauzeca.json", "utf-8", function(err, data) {
	if (err) throw err
	var podaci = JSON.parse(data);
	let moze1 = 0;
	let moze2 = 0;
	let nalaziSeVanredna = 0;
	let nalaziSePeriodicna = 0;
	let poklapanjeVP = 0;
	let poklapanjePV = 0;

	if(req.body['datum'] != null){
		//ispitivanje da li postoje periodicne kada zelimo vanrednu rezervisat
		let firstDay = (new Date(2019, req.body['datum'].substr(3,2) - 1)).getDay();
		if(firstDay - 1 < 0){
			firstDay += 7;
		}
		let dann = req.body['datum'].substr(0,2) % 7 + firstDay - 1 - 7 - 1;
		if(dann < 0){
			dann += 7;
		}
		for(let i = 0; i < podaci.periodicna.length; i++){
			if(podaci.periodicna[i].naziv == req.body['naziv'] && podaci.periodicna[i].dan == dann){
				if(((req.body['datum'].substr(3,2) <= 12 && req.body['datum'].substr(3,2) >= 10) || (req.body['datum'].substr(3,2) == 1)) && (podaci.periodicna[i].semestar == "zimski")){
					if ((req.body['pocetak'] == podaci.periodicna[i].pocetak || req.body['kraj'] == podaci.periodicna[i].kraj) || (req.body['pocetak'] < podaci.periodicna[i].pocetak && req.body['kraj'] > podaci.periodicna[i].pocetak) || (req.body['pocetak'] > podaci.periodicna[i].pocetak && req.body['pocetak'] < podaci.periodicna[i].kraj)){
    					poklapanjeVP = 1;
    				}
				}
				else if((req.body['datum'].substr(3,2) >= 2 && req.body['datum'].substr(3,2) <= 6) && (podaci.periodicna[i].semestar == "ljetni")){
					if ((req.body['pocetak'] == podaci.periodicna[i].pocetak || req.body['kraj'] == podaci.periodicna[i].kraj) || (req.body['pocetak'] < podaci.periodicna[i].pocetak && req.body['kraj'] > podaci.periodicna[i].pocetak) || (req.body['pocetak'] > podaci.periodicna[i].pocetak && req.body['pocetak'] < podaci.periodicna[i].kraj)){
    					poklapanjeVP = 1;
    				}
				}
			}
		}
		if(poklapanjeVP == 0){
			//ispitivanje poklapanja vanrednih
			for(let i = 0; i < podaci.vanredna.length; i++){
				moze1 = 0;
				if(podaci.vanredna[i].naziv == req.body['naziv'] && podaci.vanredna[i].datum.substr(0,6) == req.body['datum'].substr(0,6)){
					//pojednostavljen uslov iz kalendara
					nalaziSeVanredna = 1;
	    			if ((req.body['pocetak'] == podaci.vanredna[i].pocetak || req.body['kraj'] == podaci.vanredna[i].kraj) || (req.body['pocetak'] < podaci.vanredna[i].pocetak && req.body['kraj'] > podaci.vanredna[i].pocetak) || (req.body['pocetak'] > podaci.vanredna[i].pocetak && req.body['pocetak'] < podaci.vanredna[i].kraj)){
	    				moze1 = 1;
	    			}
					if(moze1 == 0){
						podaci.vanredna.push({
							datum : req.body['datum'],
							pocetak : req.body['pocetak'],
							kraj : req.body['kraj'],
							naziv : req.body['naziv'],
							predavac : "predavac1111"
						});
					}
				}
			}
			if(nalaziSeVanredna == 0){
				podaci.vanredna.push({
							datum : req.body['datum'],
							pocetak : req.body['pocetak'],
							kraj : req.body['kraj'],
							naziv : req.body['naziv'],
							predavac : "predavac1111"
				});
			}
		}
	} else {
		//ispitivanje da li ima poklapanja sa vanrednom
		for(let i = 0; i < podaci.vanredna.length; i++){
			if(podaci.vanredna[i].naziv == req.body['naziv']){
				let firstDay = (new Date(2019, podaci.vanredna[i].datum.substr(3,2) - 1)).getDay();
				if(firstDay - 1 < 0){
					firstDay += 7;
				}
				let dann = podaci.vanredna[i].datum.substr(0,2) % 7 + firstDay - 1 - 7 - 1;
				if(dann < 0){
					dann += 7;
				}

				if(dann == req.body['dan']){
					if(((podaci.vanredna[i].datum.substr(3,2) <= 12 && podaci.vanredna[i].datum.substr(3,2) >= 10) || (podaci.vanredna[i].datum.substr(3,2) == 1)) && (req.body['semestar'] == "zimski")){
						if ((req.body['pocetak'] == podaci.vanredna[i].pocetak || req.body['kraj'] == podaci.vanredna[i].kraj) || (req.body['pocetak'] < podaci.vanredna[i].pocetak && req.body['kraj'] > podaci.vanredna[i].pocetak) || (req.body['pocetak'] > podaci.vanredna[i].pocetak && req.body['pocetak'] < podaci.vanredna[i].kraj)){
	    					poklapanjePV = 1;
	    				}
					}
					else if((podaci.vanredna[i].datum.substr(3,2) >= 2 && podaci.vanredna[i].datum.substr(3,2) <= 6) && (req.body['semestar'] == "ljetni")){
						if ((req.body['pocetak'] == podaci.vanredna[i].pocetak || req.body['kraj'] == podaci.vanredna[i].kraj) || (req.body['pocetak'] < podaci.vanredna[i].pocetak && req.body['kraj'] > podaci.vanredna[i].pocetak) || (req.body['pocetak'] > podaci.vanredna[i].pocetak && req.body['pocetak'] < podaci.vanredna[i].kraj)){
	    					poklapanjePV = 1;
	    				}
					}
				}
			}
		}

		if(poklapanjePV == 0) {
			//ispitivanje poklapanja periodicnih
			for(let i = 0; i < podaci.periodicna.length; i++){
				moze2 = 0;
				if(podaci.periodicna[i].naziv == req.body['naziv'] && podaci.periodicna[i].dan == req.body['dan'] && podaci.periodicna[i].semestar == req.body['semestar']){
					//pojednostavljen uslov iz kalendara
					nalaziSePeriodicna = 1;
					if ((req.body['pocetak'] == podaci.periodicna[i].pocetak || req.body['kraj'] == podaci.periodicna[i].kraj) || (req.body['pocetak'] < podaci.periodicna[i].pocetak && req.body['kraj'] > podaci.periodicna[i].pocetak) || (req.body['pocetak'] > podaci.periodicna[i].pocetak && req.body['pocetak'] < podaci.periodicna[i].kraj)){
	    				moze2 = 1;
	    			}
	    			if(moze2 == 0){
	    			podaci.periodicna.push({
						dan : req.body['dan'],
						semestar : req.body['semestar'],
						pocetak : req.body['pocetak'],
						kraj : req.body['kraj'],
						naziv : req.body['naziv'],
						predavac : "predavac2222"
						});
	    			}
				}
			}
			if(nalaziSePeriodicna == 0){
				podaci.periodicna.push({
					dan : req.body['dan'],
					semestar : req.body['semestar'],
					pocetak : req.body['pocetak'],
					kraj : req.body['kraj'],
					naziv : req.body['naziv'],
					predavac : "predavac2222"
				});
			}
		}
	}

	fs.writeFile("zauzeca.json", JSON.stringify(podaci), "utf-8", function(err) {
		if (err) throw err
		res.json(podaci);
		console.log("Uspjesno dodano u JSON!");
	})
})
})

app.get("/index.js", function (req, res) {
	res.sendFile(__dirname + "/index.js");
});

app.listen(8080);