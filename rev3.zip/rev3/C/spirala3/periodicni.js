var preiodicni = [
    {
        dan: 0,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "11:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    },
    {
        dan: 0,
        semestar: "ljetni",
        pocetak: "10:00",
        kraj: "12:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    },
    {
        dan: 2,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "11:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    },
    {
        dan: 3,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "11:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    },
    {
        dan: 4,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "11:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    },
    {
        dan: 3,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "11:00",
        naziv: "0-01",
        predavac:"Neki lik" 
    }
];