window.onload = Pozivi.popuniTabeluOsoblja();

