window.onload = function () {
	Pozivi.ucitajTriSlike();
}