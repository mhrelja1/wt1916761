let Kalendar = (function(){
  var kalendarRef, mjesec;
  /*var dan, semestar, pocetak, kraj, naziv, predavac;
  var mjesecVanredna, danVanredna, godinaVanredna, pocetakVanredna, krajVanredna, nazivVanredna, predavacVanredna;*/
  let nizPeriodicnak = [], nizVanrednak = [];

  function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj){
      //if(typeof periodicnak==='object'&& dan<=6 && dan>=0){ //ako se ne pozove  metoda "ucitajPodatke" periodicnak se nece inicijlizirati pa ce biti "undefined" u suprotnom bice tipa "object"

      let zadnji = nizPeriodicnak.length-1; //posljedni objekat u nizu

      if((nizPeriodicnak[zadnji].semestar==="zimski" && mjesec>=10 && mjesec<=12)||mjesec===1 && nizPeriodicnak[zadnji].semestar==="zimski"){//ako je zimski semestar mjeseci su 10,11,12,1
        if(nizPeriodicnak.length!==0 && nizPeriodicnak[zadnji].dan<=6 && nizPeriodicnak[zadnji].dan>=0) {   //ako nije inicijaliziran niz ucitajPodatke nije pokrenuta
          //alert("U testu kaze da je UNDEFINED " + document.getElementsByClassName("col")[7+(nizPeriodicnak[zadnji].dan)] + " a nije, kao sto i nije kada se pozove iz rezervacija.js");//U testu pise da je undefined, a u stvari je div

          let brojCelije = document.getElementsByClassName("col")[7+(nizPeriodicnak[zadnji].dan)].getAttribute('value');//ide od 7 zato sto je prethodnih osam divova "col" od 0-7 dodjeljeno nazivima dana u sedmici

          for (let i = parseInt(brojCelije)-1; i < 34; i+=7) {                                  //parseInt(brojCelije)-1, -1 zato sto sam poceo inicijalizaciju atributa value divova "col" od 1-ce, a ne od 0
            if (document.getElementsByClassName("dan")[i].textContent!=0)                       //operator "!=" ce konvertovat udefined u 0
              document.getElementsByClassName("slobodna")[i].style.backgroundColor = "red";
          }
        }
      }else if (nizPeriodicnak[zadnji].semestar==="ljetni" && mjesec>=2 && mjesec<=5) { //ako je ljetni semestar mjeseci su 2,3,4,5
        if(nizPeriodicnak.length!==0 && nizPeriodicnak[zadnji].dan<=6 && nizPeriodicnak[zadnji].dan>=0) {
          let brojCelije = document.getElementsByClassName("col")[7+(nizPeriodicnak[zadnji].dan)].getAttribute('value');//ide od 7 zato sto je prethodnih osam divova "col" od 0-7 dodjeljeno nazivima dana u sedmici

          for (let i = parseInt(brojCelije)-1; i < 34; i+=7) {                                  //parseInt(brojCelije)-1, -1 zato sto sam poceo inicijalizaciju atributa value divova "col" od 1-ce, a ne od 0
            if (document.getElementsByClassName("dan")[i].textContent!=0)                       //operator "!=" ce konvertovat udefined u 0
              document.getElementsByClassName("slobodna")[i].style.backgroundColor = "red";
          }
        }
      }

      let zadnjiV = nizVanrednak.length-1; //posljedni objekat u nizu
      let mjesecVanr = nizVanrednak[zadnjiV].datum[3]+nizVanrednak[zadnjiV].datum[4];

      if(mjesec===parseInt(mjesecVanr)){ //ako je mjesec razlicit od mjeseca u objektu vandredna
        let danVanr = nizVanrednak[zadnjiV].datum[0]+nizVanrednak[zadnjiV].datum[1];
        if(nizVanrednak.length!==0 && parseInt(danVanr)<=30 && parseInt(danVanr)>=1){
          //if mjesec
          let brojCelije = document.getElementsByClassName("col")[7+parseInt(danVanr)].getAttribute('value'); //brojCelije ce biti veca za 1 jer value atrubut "col" diva ide od 1, pa ga treba smanjiti za 1
          brojCelije-=1;
          document.getElementsByClassName("slobodna")[parseInt(brojCelije)+3].style.backgroundColor = "red"; // +3 zato sto su prva 4 diva "dan" nemaju vrijednost
        }
      }

  }
  function ucitajPodatke(periodicna, vanredna){
    nizPeriodicnak = periodicna;
    nizVanrednak = vanredna;
    /*dan = periodicna.dan;
    semestar= periodicna.semestar;
    pocetak = periodicna.pocetak;
    kraj = periodicna.kraj;
    naziv = periodicna.naziv;
    predavac =periodicna.predavac;

    mjesecVanredna = vanredna.datum[4]+vanredna.datum[5];
    danVanredna = vanredna.datum[0]+vanredna.datum[1];
    godinaVanredna = vanredna.datum[6]+vanredna.datum[7]+vanredna.datum[8]+vanredna.datum[9];
    pocetakVanredna = vanredna.pocetak;
    krajVanredna = vanredna.kraj;
    nazivVanredna = vanredna.naziv;
    predavacVanredna = vanredna.predavac;*/
  }
  function iscrtajKalendar(kalendarRef, mjesec){
    if(mjesec===12){//Nije zavrseno bojenje
      let imeMjeseca = kalendarRef.getElementsByClassName("month-indicator")[0];
      imeMjeseca.innerHTML="DECEMBAR";
      let prvaKol = kalendarRef.getElementsByClassName("col")[7];
      prvaKol.remove();
      prvaKol = kalendarRef.getElementsByClassName("col")[7];
      prvaKol.remove();
      prvaKol = kalendarRef.getElementsByClassName("col")[7];
      prvaKol.remove();
      prvaKol = kalendarRef.getElementsByClassName("col")[7];
      prvaKol.remove();
      prvaKol = kalendarRef.getElementsByClassName("col")[37];
      prvaKol.remove();
      let dijete = document.createElement("div");
      dijete.innerHTML=31;
      dijete.style.border= "3px solid #346eeb";
      dijete.style.height="50px";
      dijete.style.position="relative";
      dijete.style.float="left";
      dijete.style.boxSizing = "border-box";
      dijete.style.width="67px";
      dijete.style.textAlign = "center";
      dijete.style.backgroundColor="white";

      let dijete1 = document.createElement("div");
      dijete.appendChild(dijete1);
      dijete1.style.position="absolute";
      dijete1.style.width="100%";
      dijete1.style.height="19px";
      dijete1.style.top="25px";
      dijete1.style.borderTop="3px solid #346eeb";
      dijete1.style.backgroundColor="#90f740";
      dijete1.style.boxSizing="border-box";

      let roditelj = kalendarRef.getElementsByClassName("date-grid")[0];
      roditelj.appendChild(dijete);
    }

  }
  return {
  obojiZauzeca: obojiZauzeca,
  ucitajPodatke: ucitajPodatke,
  iscrtajKalendar: iscrtajKalendar
  }
}());
//Kalendar.iscrtajKalendar(document.getElementsByClassName("calendar")[0], 12);

let periodicna1 = {
  dan: 0,
  semestar: "zimski",
  pocetak: "12:00",
  kraj: "15:00",
  naziv: "VA",
  predavac: "Gilbert"
};
let vanredna1 = {
  datum: "30.11.2019",
  pocetak: "15:00",
  kraj: "17:00",
  naziv: "MA",
  predavac: "Walter"
};
let periodicna2 = {
  dan: 3,
  semestar: "zimski",
  pocetak: "6:00",
  kraj: "9:00",
  naziv: "1-03",
  predavac: "HAimd"
};
let vanredna2 = {
  datum: "01.11.2020",
  pocetak: "17:00",
  kraj: "19:00",
  naziv: "0-06",
  predavac: "Adnan"
};
let nizPeriodicna = [], nizVanredna = [];
nizPeriodicna.push(periodicna1);
nizPeriodicna.push(periodicna2);
nizVanredna.push(vanredna1);
nizVanredna.push(vanredna2);
Kalendar.ucitajPodatke(nizPeriodicna, nizVanredna);

let periodicna3 = {
  dan: 0,
  semestar: "ljetni",
  pocetak: "6:00",
  kraj: "9:00",
  naziv: "1-03",
  predavac: "HAimd"
};
let vanredna3 = {
  datum: "3.12.2020",
  pocetak: "17:00",
  kraj: "19:00",
  naziv: "0-06",
  predavac: "Ado"
};
let noviPeriodicna = [], noviVanredna = [];
noviPeriodicna.push(periodicna3);
noviVanredna.push(vanredna3);
//Kalendar.ucitajPodatke(noviPeriodicna, noviVanredna);
Kalendar.obojiZauzeca(document.getElementsByClassName("calendar")[0], 11, "1-15", "12:00", "13:30");
