function dajPeriodicnaZauzeca() {
    let periodicna = [{
            dan: 2,
            semestar: "zimski",
            pocetak: "11:00",
            kraj: "12:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            dan: 2,
            semestar: "zimski",
            pocetak: "11:00",
            kraj: "12:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        }
     
    ]
    return periodicna;
}
function dajVanrednaZauzeca() {
    let vanredna = [{
            datum: "12.11.2019",
            pocetak: "10:00",
            kraj: "11:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            datum: "17.11.2019",
            pocetak: "11:00",
            kraj: "12:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            datum: "19.11.2019",
            pocetak: "12:00",
            kraj: "13:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            datum: "29.11.2019",
            pocetak: "13:00",
            kraj: "14:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            datum: "09.11.2019",
            pocetak: "14:00",
            kraj: "15:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        }
    ]
    return vanredna;
}
